# Copyright (c) 2011 Hesky Fisher.
# See LICENSE.txt for details.

"""This package abstracts os details for plover."""

__all__ = ['comscan', 'config', 'keyboardcontrol', 'processlock']
