# Copyright (c) 2010 Joshua Harlan Lifton.
# See LICENSE.txt for details.

"""GUI components for the Plover application."""
